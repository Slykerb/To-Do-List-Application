#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboBox->addItem("Monday");
    ui->comboBox->addItem("Tuesday");
    ui->comboBox->addItem("Wednesday");
    ui->comboBox->addItem("Thursday");
    ui->comboBox->addItem("Friday");
    ui->comboBox->addItem("Saturday");
    ui->comboBox->addItem("Sunday");
    ui->label_10->hide();
    ui->label_3->hide();
    ui->label_11->hide();
    ui->label_12->hide();
    ui->label_13->hide();
    ui->label_14->hide();
    ui->label_15->hide();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString value=ui->textEdit->toPlainText();
    QString toadd;
    QString day=ui->comboBox->currentText();
    std::stack<QString> temp;
    bool option=false;
    if(ui->checkBox->isChecked())
    {
        option=true;
    }

    if(day=="Monday" || option)
    {
        toadd="";
        ui->label_10->show();
        ui->textEdit->clear();
        qm.push(value);

        while(!qm.empty())
        {
            QString current_value=qm.top();
            temp.push(current_value);\
                toadd+=temp.top();
            toadd+="\n";
            qm.pop();
        }
        while(!temp.empty())
        {
            qm.push(temp.top());
            temp.pop();
        }
        ui->label_10->setText(toadd);
    }
    if(day=="Tuesday" || option)
    {
        toadd="";
        ui->label_3->show();
        ui->textEdit->clear();
        qt.push(value);

        while(!qt.empty())
        {
            QString current_value=qt.top();
            temp.push(current_value);\
                toadd+=temp.top();
            toadd+="\n";
            qt.pop();
        }
        while(!temp.empty())
        {
            qt.push(temp.top());
            temp.pop();
        }
        ui->label_3->setText(toadd);
    }
    if(day=="Wednesday" || option)
    {
        toadd="";
        ui->label_11->show();
        ui->textEdit->clear();
        qw.push(value);

        while(!qw.empty())
        {
            QString current_value=qw.top();
            temp.push(current_value);\
                toadd+=temp.top();
            toadd+="\n";
            qw.pop();
        }
        while(!temp.empty())
        {
            qw.push(temp.top());
            temp.pop();
        }
        ui->label_11->setText(toadd);
    }
    if(day=="Thursday" || option)
    {
        toadd="";
        ui->label_12->show();
        ui->textEdit->clear();
        qr.push(value);

        while(!qr.empty())
        {
            QString current_value=qr.top();
            temp.push(current_value);\
                toadd+=temp.top();
            toadd+="\n";
            qr.pop();
        }
        while(!temp.empty())
        {
            qr.push(temp.top());
            temp.pop();
        }
        ui->label_12->setText(toadd);
    }
    if(day=="Friday" || option)
    {
        toadd="";
        ui->label_13->show();
        ui->textEdit->clear();
        qf.push(value);

        while(!qf.empty())
        {
            QString current_value=qf.top();
            temp.push(current_value);\
                toadd+=temp.top();
            toadd+="\n";
            qf.pop();
        }
        while(!temp.empty())
        {
            qf.push(temp.top());
            temp.pop();
        }
        ui->label_13->setText(toadd);
    }
    if(day=="Saturday" || option)
    {
        toadd="";
        ui->label_14->show();
        ui->textEdit->clear();
        qs.push(value);

        while(!qs.empty())
        {
            QString current_value=qs.top();
            temp.push(current_value);\
                toadd+=temp.top();
            toadd+="\n";
            qs.pop();
        }
        while(!temp.empty())
        {
            qs.push(temp.top());
            temp.pop();
        }
        ui->label_14->setText(toadd);
    }
    if(day=="Sunday" || option)
    {
        toadd="";
        ui->label_15->show();
        ui->textEdit->clear();
        qsu.push(value);

        while(!qsu.empty())
        {
            QString current_value=qsu.top();
            temp.push(current_value);\
                toadd+=temp.top();
            toadd+="\n";
            qsu.pop();
        }
        while(!temp.empty())
        {
            qsu.push(temp.top());
            temp.pop();
        }
        ui->label_15->setText(toadd);
    }
}
